#include <stdio.h>

int main()
{
    unsigned int n; 
    scanf("%X", &n);
    printf("%u", n);
    return 0;
}
 