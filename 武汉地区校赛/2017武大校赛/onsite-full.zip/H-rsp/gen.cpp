#include <bits/stdc++.h>
using namespace std;
int main()
{
	random_device rd;
	cout << rd() % 524288 << endl;
	cerr << "6d37d07307058f1d44d5dd89cb55060b6c2bf3a1\n";
	return 0;
}
